import TodoList from "./components/todoCard"
import Header from "./components/header";
import './App.css';

const { Component } = require("react");

class TodoApp extends Component {
    state = {
        todo: "",
        todos: [],
        curId: 3,
        featuredItem: {}

    }

    // on calling return mock data
    getMockdata = () => {
        // mockTodoData
        const mockTodoData = [
            { id: 0, name: 'I need to do Task1' },
            { id: 1, name: 'I need to do Task2' },
            { id: 2, name: 'I need to do Task3' }
        ]
        // console.log(mockTodoData)
        return mockTodoData
    }

    // Update todos state with this mock data during mouting cycle
    componentWillMount() {
        let mockTodoData = this.getMockdata()
        let feaItem = mockTodoData[0]
        // assigning the first item to the featured item
        this.setState({ featuredItem: feaItem })
        let newTodoList = [...mockTodoData]
        this.setState({ todos: newTodoList })
    }

    componentDidUpdate(pP, pS, sS) {

        let newItem = this.randomFeaturedItemSelector()
        console.log("random " + newItem)
        if (this.state.todos.length !== pS.todos.length) {
            this.setState({ featuredItem: newItem })
        }
    }

    randomFeaturedItemSelector = () => {
        let rNum = Math.random();
        rNum = (rNum * (this.state.curId))
        rNum = Math.floor(rNum);
        let newFeaturedItem = this.state.todos[rNum]
        console.log("inside random " + newFeaturedItem)
        return newFeaturedItem
    }


    // input field change handler
    changeHandler = event => {
        let newVal = event.target.value

        this.setState({ todo: newVal })
        // console.log(this.state.todo)
    }


    // add todo handler
    addTodoHandler = () => {
        if (this.state.todo !== "") {

            let NewId = this.state.curId + 1
            let newTodo = { id: this.NewId, name: this.state.todo }
            // console.log(NewId)

            let newTodoList = [newTodo, ...this.state.todos]
            // console.log(newTodoList)
            this.setState({ todos: newTodoList })
            this.setState({ curId: NewId })
        }
    }
    render() {
        return (

            <div className="todo-app">
                <Header />

                <div className="inputForm">
                    <input type="text" value={this.state.todo} onChange={this.changeHandler} placeholder="add something"></input>
                    <button className="addTodo-btn" onClick={this.addTodoHandler}>Add Todo </button>

                </div>
                <ul className="todo-list">
                    <div className="todoCard">
                        <h3>{this.state.featuredItem.name} <br /><span className="featuredItem">  ~featured~ </span></h3>
                    </div>

                    {this.state.todos.map(todo => (<TodoList name={todo.name} />))}

                </ul>

            </div>

        )
    };

};

export default TodoApp;

