
const { Component } = require("react");

class TodoList extends Component {
    // intializing state with empty Array

    render() {
        console.log(this.props.name)
        return (
            <li className="todoListComponent">
                <div className="todoCard">
                    <h3>{this.props.name}</h3>
                </div>
            </li>
        )
    }
}

export default TodoList